import numpy as np
from vi import run_value_iteration
from pi import run_policy_iteration
from mpi import run_modified_policy_iteration
from gsmpi import run_gauss_seidel_modified_policy_iteration
from isc_vi import run_isc_value_iteration
from isc_mpi import run_isc_modified_policy_iteration
from isc_gsmpi import run_isc_gauss_seidel_modified_policy_iteration
from limiting_dist import calculate_limiting_distribution
from p2_visualizer import plot_optimal_policy
from pi_old import evaluate_policy_old

#####################################################
##          Controls & Params                      ##
#####################################################
build_mdp = True
A = np.arange(1, 121+1)
S = np.arange(1, 120+1)

# Read in the data.
with open("data/transition_matrix.npy", "rb") as f:
    P = np.load(f)

# Save the reward vector.
with open("data/reward_vector.npy", "rb") as f:
    r = np.load(f)

#v_star, d_star, P_dstar, results_table = run_value_iteration(P, r, A, S, epsilon=0.1, lamb=0.99)
#print(d_star)
v_1, d_star_pi, Pd_pi = run_policy_iteration(P, r, A, S, lamb=0.99)
print(v_1)
#upsilon_n = run_modified_policy_iteration(P, r, A, S, epsilon=0.1, lamb=0.99, m=90, max_iter=1500)
#print(upsilon_n)
#upsilon_n_gs = run_gauss_seidel_modified_policy_iteration(P, r, A, S, epsilon=0.1, lamb=0.99, m=90, max_iter=1500)
#print(upsilon_n_gs)
#v_n, d, Pd, v_approx = run_isc_value_iteration(P, r, A, S, epsilon=0.1, lamb=0.99, max_iter=5000)
#print("V approximate form ISVI...\n",v_approx)
#with open("Pd.npy", "wb") as f:
#    np.save(f, Pd_pi)
#upsilon_n, d, v_approx_2 = run_isc_modified_policy_iteration(P, r, A, S, epsilon=0.1, lamb=0.99, m=90, max_iter=5000)
#print(d)
#print("V approximate from ISCMPI...\n", v_approx_2)
#print("ARE THE TWO EQUAL???", np.array_equal(d_star_pi, d))
#upsilon_n, dnp1 = run_isc_gauss_seidel_modified_policy_iteration(P, r, A, S, epsilon=0.1, lamb=0.99, m=10, max_iter=5000)
#print("ARE THE TWO EQUAL???", np.array_equal(dnp1, d))


################################################
##              Problem 2                     ##
################################################
pi = calculate_limiting_distribution(Pd_pi)

# Plot a bar graph: states (x) vs. optimal decision d*(s)
plot_optimal_policy(S, d_star_pi, v_1, pi[:,0])


################################################
##              Problem 4                     ##
################################################
# Evaluate d_old
v_old, d_old, Pd_old = evaluate_policy_old(S, P, r, age=62, lamb=0.99)
pi_old = calculate_limiting_distribution(Pd_old)
#plot_optimal_policy(S, d_old, v_old, pi_old[:,0])